loadJs("/js/barrage.js");
loadJs("/js/calendar.js");
loadJs("/js/heimu.js");
loadJs("/js/commentBarrage.js");
loadJs("/js/bbtalk.js");
loadJs("/js/resizeTop.js");